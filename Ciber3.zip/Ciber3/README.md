Installation for Termux

$ apt update

$ apt upgrade

$ apt install python

$ apt install git

$ git clone https://github.com/krisnaramdhani/tilwar

$ cd tilwar

$ python3 til.py

------------------------------

Installation for VPS

$ git clone https://github.com/krisnaramdhani/tilwar

$ cd tilwar

$ python3 til.py

------------------------------

https://line.me/ti/p/~batara_dewa
